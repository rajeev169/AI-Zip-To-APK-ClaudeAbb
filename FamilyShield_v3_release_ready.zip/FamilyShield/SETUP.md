# Family Shield – setup guide

One app for both phones. The phone decides automatically after Google sign-in:
- Gmail added by a parent → **Child** phone (connects to that parent)
- Gmail already a parent, or brand-new → **Parent** phone
- New account can also tap "I'm a child, waiting for my parent"

## 1. Firebase (one time, about 10 minutes)

1. Go to https://console.firebase.google.com → **Add project** (e.g. "Family Shield").
2. **Add app → Android**
   - Package name: `com.rajeev.familyshield`
   - SHA-1: `D1:B6:2E:76:84:7A:7B:75:01:21:47:7D:C2:B8:1D:97:89:71:A6:E5`
   - (Also add SHA-256 in Project settings: `CA:CD:33:65:04:63:E6:B9:98:45:9E:E2:21:F5:A0:69:50:4D:BC:27:C3:34:8A:45:39:09:5A:F6:7D:D3:54:01`)
   - These come from `app/debug.keystore`, which is included so the SHA-1 never changes between builds.
3. Download **google-services.json** and put it in the **app/** folder (next to `build.gradle.kts`).
4. **Build → Authentication → Sign-in method → Google → Enable** (pick a support email). Save.
   Then download google-services.json **again** (it now contains the web client ID that Google sign-in needs).
5. **Build → Firestore Database → Create database** (Production mode, region `asia-south1` Mumbai).
6. Firestore → **Rules** tab → paste everything from `firestore.rules` → **Publish**.

## 2. Build the APK

- Upload the project to your GitHub repo (with `app/google-services.json` inside) and run your ZIP-to-APK workflow,
  or use the included workflow `.github/workflows/build.yml` (Actions → Build APK → download the artifact).
- Output: `app/build/outputs/apk/debug/app-debug.apk`

## 3. Try it

1. Parent phone: install → Sign in with Google → **Continue as parent** → **Add child** (name + child's Gmail).
2. Child phone: install → Sign in with the child's Gmail → it connects automatically.
3. Child phone: read the notice → allow each item (Usage access, App blocking, Location "Allow all the time",
   Uninstall protection, Battery).

### Optional: true OS-level uninstall blocking

For a normal APK or Play Store installation, Android does not allow an app to intercept the
system uninstall screen and demand an app PIN. The standard device-admin option only adds a
confirmation step. For a managed child phone, Family Shield supports Android **device-owner**
mode, which blocks uninstall at the operating-system level.

Device-owner provisioning must be done on a new or factory-reset test phone before normal use:

```text
adb install app-debug.apk
adb shell dpm set-device-owner \
  com.rajeev.familyshield/.child.AdminReceiver
```

This command requires USB debugging and a device with no existing accounts or device owner;
Android may require a factory reset first. It is intended for dedicated child devices and is
not required for ordinary testing. After provisioning, the child app visibly shows that
uninstall protection is enforced. To authorize removal, the parent must open Family Shield on
the child phone, choose **Parent: allow uninstall**, enter the synced parent PIN, and then use
Android's App info uninstall control. Without that PIN, Android blocks the uninstall operation.

On already-configured phones, the Accessibility service also provides a transparent
best-effort uninstall guard: when Android Settings or the package installer shows an uninstall
flow targeting Family Shield, the app opens a visible Family Shield PIN screen. A correct parent
PIN grants a 60-second window for the parent-approved uninstall flow; an incorrect or missing
PIN returns to the home screen. This is manufacturer-dependent and can be bypassed if
Accessibility is disabled, so device-owner mode remains the strongest option.

**App blocking switch greyed out?** Android 13+ restricts Accessibility for apps installed from an APK file.
Open *Settings → Apps → Family Shield → ⋮ (top right) → Allow restricted settings*, then turn it on again.
(This does not happen for apps installed from Play Store.)

## Features

| Parent phone | Child phone |
|---|---|
| Add child by Gmail, auto-connect | Auto-detects child role from Gmail |
| Children list: online, battery, today's time, place | Permanent "supervised" notification |
| Per-app daily limits and block/allow | Block screen when limit / bedtime / study mode |
| Total daily screen-time limit | Remaining time and app limits shown |
| Bedtime schedule | Big SOS button with location |
| Study mode with chosen apps | Calls, contacts, settings always allowed |
| Usage today + 7-day chart | Uninstall protection (device admin or device-owner mode) |
| Live map, safe places (home/school) with arrive/leave alerts | Restarts automatically after reboot |
| Lock phone now, find location now | Parent PIN required to change protections in-app |
| Set parent PIN (menu) | |
| Alerts: SOS (alarm sound), new app, places, limit reached, protection turned off | |
| "Phone offline" alert if a child stops reporting (app removed, phone off, or no network) | |

### A note on uninstall protection

On ordinary APK or Play Store installs, Android does not expose a supported API for a normal
app to put a parent-PIN prompt inside the system uninstall flow. Family Shield therefore uses
device admin, protection-off alerts, and a **"phone offline"** alert (within ~40 minutes) as
the transparent fallback.

On a dedicated child phone provisioned as Android device owner, Family Shield calls the system
`setUninstallBlocked` policy. Android then blocks uninstall itself. The visible Family Shield
screen provides a **Parent: allow uninstall** action protected by the synced parent PIN; only
after successful PIN entry does the app open Android App info with uninstall permitted. The
app remains clearly identified and supervised throughout.

## Before publishing on Play Store

- Create your own upload key and set it in `app/build.gradle.kts` (release currently uses the debug key).
- Play Console declarations you will need: **Accessibility API** (parental control use), **Background location**,
  **Foreground service – special use**, **Device admin**, plus a privacy policy URL. Choose the
  "Parental control" / family category and target audience = parents.
- Play icon: `store_assets/play_store_icon_512.png`.
- Map: OpenStreetMap (no API key needed). The attribution text is shown on the map.
