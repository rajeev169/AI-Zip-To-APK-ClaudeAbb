package com.rajeev.familyshield.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rajeev.familyshield.data.formatMinutes
import com.rajeev.familyshield.ui.theme.KidOrange
import com.rajeev.familyshield.ui.theme.ShieldBlue

/** The Family Shield logo (same artwork as the launcher icon). */
@Composable
fun ShieldLogo(size: Dp = 96.dp, background: Boolean = true) {
    Box(
        Modifier
            .size(size)
            .then(if (background) Modifier.clip(RoundedCornerShape(size * 0.23f)).background(ShieldBlue) else Modifier)
    ) {
        Canvas(Modifier.size(size)) {
            val s = this.size.width / 150f
            fun p(x: Float, y: Float) = Offset(x * s, y * s)
            val shield = Path().apply {
                moveTo(75f * s, 22f * s)
                lineTo(120f * s, 38f * s); lineTo(120f * s, 75f * s)
                cubicTo(120f * s, 105f * s, 100f * s, 122f * s, 75f * s, 132f * s)
                cubicTo(50f * s, 122f * s, 30f * s, 105f * s, 30f * s, 75f * s)
                lineTo(30f * s, 38f * s); close()
            }
            drawPath(shield, Color.White)
            drawCircle(ShieldBlue, 10f * s, p(62f, 62f))
            drawPath(Path().apply {
                moveTo(45f * s, 102f * s); quadraticBezierTo(62f * s, 70f * s, 79f * s, 102f * s); close()
            }, ShieldBlue)
            drawCircle(KidOrange, 7f * s, p(91f, 78f))
            drawPath(Path().apply {
                moveTo(80f * s, 106f * s); quadraticBezierTo(91f * s, 86f * s, 102f * s, 106f * s); close()
            }, KidOrange)
        }
    }
}

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun Avatar(name: String, size: Dp = 48.dp, color: Color = MaterialTheme.colorScheme.secondary) {
    Box(
        Modifier
            .size(size)
            .background(color.copy(alpha = 0.18f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.trim().take(1).uppercase().ifBlank { "?" },
            color = color, fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleLarge
        )
    }
}

/** Horizontal usage bars: app name, bar, minutes. */
@Composable
fun UsageBars(items: List<Pair<String, Long>>, limitFor: (Int) -> Long? = { null }) {
    val max = (items.maxOfOrNull { it.second } ?: 1L).coerceAtLeast(1L)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEachIndexed { i, (name, min) ->
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    val lim = limitFor(i)
                    Text(
                        if (lim != null) "${formatMinutes(min)} / ${formatMinutes(lim)}" else formatMinutes(min),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (min.toFloat() / max).coerceIn(0.02f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    drawStopIndicator = {},
                )
            }
        }
    }
}

/** Simple 7-day bar chart. */
@Composable
fun WeekChart(days: List<Pair<String, Long>>) {
    val max = (days.maxOfOrNull { it.second } ?: 1L).coerceAtLeast(1L)
    val barColor = MaterialTheme.colorScheme.primary
    val todayColor = MaterialTheme.colorScheme.secondary
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .height(130.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            days.forEachIndexed { i, (_, min) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        if (min > 0) formatMinutes(min) else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    val frac = (min.toFloat() / max).coerceIn(0.03f, 1f)
                    Canvas(
                        Modifier
                            .width(22.dp)
                            .height((100 * frac).dp)
                    ) {
                        drawRoundRect(
                            if (i == days.lastIndex) todayColor else barColor,
                            size = Size(size.width, size.height),
                            cornerRadius = CornerRadius(6.dp.toPx())
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            days.forEach { (label, _) ->
                Text(
                    label, Modifier.weight(1f), style = MaterialTheme.typography.labelSmall,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun StatusDot(on: Boolean) {
    Box(
        Modifier
            .size(10.dp)
            .background(if (on) Color(0xFF12A37A) else Color(0xFF9AA3AF), CircleShape)
    )
}
