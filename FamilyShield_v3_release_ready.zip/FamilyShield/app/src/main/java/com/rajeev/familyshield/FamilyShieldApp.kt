package com.rajeev.familyshield

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import org.osmdroid.config.Configuration

class FamilyShieldApp : Application() {

    companion object {
        const val CH_MONITOR = "monitor"
        const val CH_ALERTS = "alerts"
        const val CH_SOS = "sos"
    }

    override fun onCreate() {
        super.onCreate()
        Configuration.getInstance().userAgentValue = packageName
        Configuration.getInstance().osmdroidBasePath = cacheDir
        Configuration.getInstance().osmdroidTileCache = java.io.File(cacheDir, "tiles")

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MONITOR, "Protection status", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows that Family Shield is running"
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERTS, "Child alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "New apps, places and protection changes"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SOS, "SOS alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Emergency SOS from your child"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 600)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
        )
    }
}
