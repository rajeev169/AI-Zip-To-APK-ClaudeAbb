package com.rajeev.familyshield.ui.parent

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.firebase.firestore.FieldPath
import com.rajeev.familyshield.data.AppEntry
import com.rajeev.familyshield.data.ChildInfo
import com.rajeev.familyshield.data.Day
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.Rules
import com.rajeev.familyshield.data.asFlow
import kotlinx.coroutines.launch

/** All the data a parent sees for one child. */
data class ChildData(
    val child: ChildInfo,
    val rules: Rules,
    val apps: List<AppEntry>,
    val usageByDay: Map<String, Map<String, Long>>, // day -> (package -> minutes)
) {
    val appNames: Map<String, String> = apps.associate { it.pkg to it.name }
    val today: Map<String, Long> get() = usageByDay[Day.key()] ?: emptyMap()
    fun name(pkg: String) = appNames[pkg] ?: pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChildDetail(uid: String, onBack: () -> Unit) {
    val childSnap by remember(uid) { Repo.childDoc(uid).asFlow() }.collectAsStateWithLifecycle(null)
    val rulesSnap by remember(uid) { Repo.rulesDoc(uid).asFlow() }.collectAsStateWithLifecycle(null)
    val appsSnap by remember(uid) { Repo.appsCol(uid).asFlow() }.collectAsStateWithLifecycle(null)
    val days = remember { Day.lastDays(7) }
    val usageSnap by remember(uid) {
        Repo.usageCol(uid).whereIn(FieldPath.documentId(), days).asFlow()
    }.collectAsStateWithLifecycle(null)

    val child = childSnap?.let { ChildInfo.from(it) }
    if (childSnap != null && child == null && childSnap?.metadata?.isFromCache == false) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val data = child?.let { c ->
        @Suppress("UNCHECKED_CAST")
        val usage = usageSnap?.documents?.associate { d ->
            d.id to ((d.get("apps") as? Map<String, Any?>)
                ?.mapNotNull { (k, v) -> (v as? Number)?.let { k to it.toLong() } }?.toMap() ?: emptyMap())
        } ?: emptyMap()
        ChildData(
            child = c,
            rules = Rules.from(rulesSnap),
            apps = appsSnap?.documents?.map {
                AppEntry(it.id, it.getString("name") ?: it.id, it.getLong("firstSeen") ?: 0L, it.getBoolean("pending") ?: false)
            }?.sortedBy { it.name.lowercase() } ?: emptyList(),
            usageByDay = usage,
        )
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(child?.name ?: "", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Remove this child") },
                                leadingIcon = { Icon(Icons.Filled.PersonRemove, null) },
                                onClick = { menu = false; confirmRemove = true }
                            )
                        }
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
        ) {
            TabRow(selectedTabIndex = tab) {
                listOf("Overview", "Apps", "Limits", "Location").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, maxLines = 1) })
                }
            }
            if (data == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                when (tab) {
                    0 -> OverviewTab(data, days)
                    1 -> AppsTab(data)
                    2 -> LimitsTab(data)
                    else -> LocationTab(data)
                }
            }
        }
    }

    if (confirmRemove && child != null) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            title = { Text("Remove ${child.name}?") },
            text = { Text("Their phone will be disconnected and all limits will stop. You can add them again later.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = false
                    scope.launch {
                        runCatching { Repo.removeChild(child) }
                        onBack()
                    }
                }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel") } }
        )
    }
}
