package com.rajeev.familyshield.data

import android.os.Build
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Everything that talks to Firestore lives here. */
object Repo {
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val me: FirebaseUser? get() = auth.currentUser

    fun emailKey(email: String) = email.trim().lowercase(Locale.ROOT)

    fun userDoc(uid: String) = db.collection("users").document(uid)
    fun inviteDoc(email: String) = db.collection("invites").document(emailKey(email))
    fun childDoc(uid: String) = db.collection("children").document(uid)
    fun rulesDoc(childUid: String) = childDoc(childUid).collection("control").document("rules")
    fun appsCol(childUid: String) = childDoc(childUid).collection("apps")
    fun usageCol(childUid: String) = childDoc(childUid).collection("usage")
    fun alertsCol(parentUid: String) = userDoc(parentUid).collection("alerts")

    // ---------- Role resolution ----------

    sealed interface Resolved {
        data object NewAccount : Resolved
        data object Parent : Resolved
        data class Child(val parentName: String) : Resolved
        data object Waiting : Resolved
    }

    /** Decides automatically whether this Gmail is a parent or a child phone. */
    suspend fun resolve(prefs: Prefs): Resolved {
        val user = me ?: error("Not signed in")
        val email = emailKey(user.email ?: "")
        val userSnap = userDoc(user.uid).get().await()
        val role = userSnap.getString("role")

        if (role == Role.PARENT) {
            prefs.role = Role.PARENT
            return Resolved.Parent
        }
        if (role == Role.CHILD) {
            val child = childDoc(user.uid).get().await()
            if (child.exists()) {
                saveChildPrefs(prefs, child)
                return Resolved.Child(child.getString("parentName") ?: "Parent")
            }
            // Parent removed this phone earlier. Re-link if a new invite exists.
        }
        val invite = Invite.from(inviteDoc(email).get().await())
        if (invite != null) {
            linkChild(invite, prefs)
            return Resolved.Child(invite.parentName)
        }
        prefs.linked = false
        return if (role == Role.CHILD) Resolved.Waiting else Resolved.NewAccount
    }

    private fun saveChildPrefs(prefs: Prefs, child: DocumentSnapshot) {
        prefs.role = Role.CHILD
        prefs.linked = true
        prefs.parentUid = child.getString("parentUid") ?: ""
        prefs.parentName = child.getString("parentName") ?: "Parent"
        prefs.childName = child.getString("name") ?: ""
    }

    suspend fun becomeParent(prefs: Prefs) {
        val user = me ?: return
        userDoc(user.uid).set(
            mapOf(
                "role" to Role.PARENT,
                "email" to emailKey(user.email ?: ""),
                "name" to (user.displayName ?: "Parent"),
                "createdAt" to System.currentTimeMillis(),
            )
        ).await()
        prefs.role = Role.PARENT
    }

    suspend fun linkChild(invite: Invite, prefs: Prefs) {
        val user = me ?: return
        val email = emailKey(user.email ?: "")
        val name = invite.childName.ifBlank { user.displayName ?: "Child" }
        val now = System.currentTimeMillis()
        val batch = db.batch()
        batch.set(
            userDoc(user.uid), mapOf(
                "role" to Role.CHILD,
                "email" to email,
                "name" to name,
                "parentUid" to invite.parentUid,
                "createdAt" to now,
            )
        )
        batch.set(
            childDoc(user.uid), mapOf(
                "parentUid" to invite.parentUid,
                "parentName" to invite.parentName,
                "name" to name,
                "email" to email,
                "device" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "linkedAt" to now,
                "lastSeen" to now,
            )
        )
        batch.update(inviteDoc(email), mapOf("status" to "linked", "childUid" to user.uid))
        batch.commit().await()
        prefs.role = Role.CHILD
        prefs.linked = true
        prefs.parentUid = invite.parentUid
        prefs.parentName = invite.parentName
        prefs.childName = name
        prefs.knownApps = emptySet()
        prefs.insidePlaces = null
    }

    // ---------- Parent actions ----------

    /** Returns null on success or a message to show. */
    suspend fun addChild(childName: String, childEmail: String): String? {
        val user = me ?: return "Please sign in again"
        val key = emailKey(childEmail)
        if (!key.contains("@") || !key.contains(".")) return "Enter a valid Gmail address"
        if (key == emailKey(user.email ?: "")) return "This is your own Gmail. Enter your child's Gmail."
        return try {
            val existing = inviteDoc(key).get().await()
            if (existing.exists()) {
                return if (existing.getString("parentUid") == user.uid) "You already added this Gmail"
                else "This Gmail is already connected to another parent"
            }
            inviteDoc(key).set(
                mapOf(
                    "parentUid" to user.uid,
                    "parentName" to (user.displayName ?: "Parent"),
                    "parentEmail" to emailKey(user.email ?: ""),
                    "childName" to childName.trim(),
                    "status" to "pending",
                    "createdAt" to System.currentTimeMillis(),
                )
            ).await()
            null
        } catch (e: Exception) {
            if (e.message?.contains("PERMISSION_DENIED") == true)
                "This Gmail is already connected to another parent"
            else e.message ?: "Could not add child"
        }
    }

    suspend fun removeInvite(email: String) {
        inviteDoc(email).delete().await()
    }

    suspend fun removeChild(child: ChildInfo) {
        val batch = db.batch()
        batch.delete(childDoc(child.uid))
        if (child.email.isNotBlank()) batch.delete(inviteDoc(child.email))
        batch.commit().await()
    }

    fun updateRules(childUid: String, fields: Map<String, Any?>) {
        rulesDoc(childUid).set(fields, SetOptions.merge())
    }

    fun setBlocked(childUid: String, pkg: String, blocked: Boolean) {
        updateRules(
            childUid,
            mapOf("blocked" to if (blocked) FieldValue.arrayUnion(pkg) else FieldValue.arrayRemove(pkg))
        )
    }

    fun setApproveNew(childUid: String, on: Boolean) {
        updateRules(childUid, mapOf("approveNew" to on))
    }

    fun approveApp(childUid: String, pkg: String) {
        updateRules(childUid, mapOf("approved" to FieldValue.arrayUnion(pkg)))
    }

    fun setLimit(childUid: String, pkg: String, minutes: Long) {
        updateRules(childUid, mapOf("limits" to mapOf(pkg to if (minutes > 0) minutes else FieldValue.delete())))
    }

    fun setStudyAllowed(childUid: String, pkgs: Set<String>) {
        updateRules(childUid, mapOf("studyAllowed" to pkgs.toList()))
    }

    fun setPlaces(childUid: String, places: List<Place>) {
        updateRules(childUid, mapOf("places" to places.map { it.toMap() }))
    }

    fun sendCommand(childUid: String, type: String) {
        updateRules(
            childUid,
            mapOf("cmdId" to UUID.randomUUID().toString(), "cmdType" to type, "cmdTime" to System.currentTimeMillis())
        )
    }

    /** The parent PIN is parent-wide, so it is written to every child's rules. */
    suspend fun setParentPin(pin: String) {
        val uid = me?.uid ?: return
        userDoc(uid).set(mapOf("pin" to pin), SetOptions.merge()).await()
        val kids = db.collection("children").whereEqualTo("parentUid", uid).get().await()
        if (kids.isEmpty) return
        val batch = db.batch()
        kids.documents.forEach { batch.set(rulesDoc(it.id), mapOf("pin" to pin), SetOptions.merge()) }
        batch.commit().await()
    }

    suspend fun currentPin(): String {
        val uid = me?.uid ?: return ""
        return userDoc(uid).get().await().getString("pin") ?: ""
    }

    fun markAlertRead(parentUid: String, id: String) {
        alertsCol(parentUid).document(id).update("read", true)
    }

    suspend fun markAllRead(parentUid: String) {
        val unread = alertsCol(parentUid).whereEqualTo("read", false).get().await()
        if (unread.isEmpty) return
        val batch = db.batch()
        unread.documents.forEach { batch.update(it.reference, "read", true) }
        batch.commit().await()
    }

    // ---------- Child side ----------

    fun sendAlert(
        prefs: Prefs,
        type: String,
        title: String,
        message: String,
        lat: Double? = null,
        lng: Double? = null,
    ) {
        val user = me ?: return
        if (prefs.parentUid.isBlank()) return
        val data = hashMapOf<String, Any>(
            "type" to type,
            "childUid" to user.uid,
            "childName" to prefs.childName.ifBlank { user.displayName ?: "Child" },
            "title" to title,
            "message" to message,
            "time" to System.currentTimeMillis(),
            "read" to false,
        )
        if (lat != null && lng != null) {
            data["lat"] = lat
            data["lng"] = lng
        }
        alertsCol(prefs.parentUid).add(data)
    }

    fun updateChildStatus(fields: Map<String, Any?>) {
        val user = me ?: return
        childDoc(user.uid).update(fields)
    }

    suspend fun signOut() {
        auth.signOut()
    }
}

// ---------- Small helpers ----------

fun DocumentReference.asFlow(): Flow<DocumentSnapshot?> = callbackFlow {
    val reg = addSnapshotListener { snap, _ -> trySend(snap) }
    awaitClose { reg.remove() }
}

fun Query.asFlow(): Flow<QuerySnapshot?> = callbackFlow {
    val reg = addSnapshotListener { snap, _ -> trySend(snap) }
    awaitClose { reg.remove() }
}

object Day {
    private val fmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    fun key(time: Long = System.currentTimeMillis()): String = fmt.format(Date(time))
    fun startOfToday(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun lastDays(n: Int): List<String> {
        val c = Calendar.getInstance()
        val out = ArrayList<String>()
        repeat(n) {
            out.add(0, fmt.format(c.time))
            c.add(Calendar.DAY_OF_YEAR, -1)
        }
        return out
    }

    fun shortLabel(key: String): String = try {
        val d = fmt.parse(key)!!
        SimpleDateFormat("EEE", Locale.getDefault()).format(d)
    } catch (e: Exception) {
        key.takeLast(2)
    }
}

fun formatMinutes(min: Long): String {
    if (min <= 0) return "0m"
    val h = min / 60
    val m = min % 60
    return when {
        h == 0L -> "${m}m"
        m == 0L -> "${h}h"
        else -> "${h}h ${m}m"
    }
}

fun formatAgo(time: Long): String {
    if (time <= 0) return "never"
    val diff = (System.currentTimeMillis() - time) / 1000
    return when {
        diff < 60 -> "just now"
        diff < 3600 -> "${diff / 60} min ago"
        diff < 86400 -> "${diff / 3600} hr ago"
        else -> "${diff / 86400} days ago"
    }
}

fun formatClock(minutes: Int): String {
    val h = (minutes / 60) % 24
    val m = minutes % 60
    val ampm = if (h < 12) "AM" else "PM"
    val h12 = if (h % 12 == 0) 12 else h % 12
    return String.format(Locale.US, "%d:%02d %s", h12, m, ampm)
}
