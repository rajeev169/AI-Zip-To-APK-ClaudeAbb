package com.rajeev.familyshield.ui.child

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rajeev.familyshield.child.AdminReceiver
import com.rajeev.familyshield.child.BlockPolicy
import com.rajeev.familyshield.child.Essentials
import com.rajeev.familyshield.child.MonitorService
import com.rajeev.familyshield.child.Perms
import com.rajeev.familyshield.child.Sos
import com.rajeev.familyshield.child.UsageTracker
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.Rules
import com.rajeev.familyshield.data.asFlow
import com.rajeev.familyshield.data.formatClock
import com.rajeev.familyshield.data.formatMinutes
import com.rajeev.familyshield.ui.common.SectionCard
import com.rajeev.familyshield.ui.common.ShieldLogo
import com.rajeev.familyshield.ui.common.UsageBars
import com.rajeev.familyshield.ui.theme.SafeGreen
import com.rajeev.familyshield.ui.theme.SosRed
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Re-reads permission state whenever the user comes back from a Settings page. */
@Composable
private fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
fun ChildRoot(parentName: String, onUnlinked: () -> Unit) {
    val ctx = LocalContext.current
    val uid = Repo.me?.uid ?: return
    val tick = rememberResumeTick()
    val coreReady = remember(tick) { Perms.coreReady(ctx) }
    var showSetup by remember { mutableStateOf(!Perms.coreReady(ctx)) }

    // Parent removed this phone -> go back to the waiting screen.
    val childSnap by remember(uid) { Repo.childDoc(uid).asFlow() }.collectAsStateWithLifecycle(null)
    LaunchedEffect(childSnap) {
        val s = childSnap
        if (s != null && !s.exists() && !s.metadata.isFromCache) {
            Prefs(ctx).linked = false
            MonitorService.stop(ctx)
            onUnlinked()
        }
    }
    LaunchedEffect(tick) { if (Prefs(ctx).linked) MonitorService.start(ctx) }

    if (showSetup || !coreReady) {
        SetupScreen(parentName, tick, onDone = { showSetup = false })
    } else {
        ChildHome(parentName, uid, tick, onOpenSetup = { showSetup = true })
    }
}

// ---------------- Setup ----------------

@Composable
private fun SetupScreen(parentName: String, tick: Int, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var accepted by remember { mutableStateOf(prefs.disclosureAccepted) }
    var refresh by remember { mutableIntStateOf(0) }
    var showA11yInfo by remember { mutableStateOf(false) }
    val key = tick + refresh

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refresh++; MonitorService.start(ctx)
    }
    val bgLocLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refresh++; MonitorService.start(ctx)
    }
    val adminLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh++ }

    val notifOk = remember(key) { Perms.hasNotifications(ctx) }
    val usageOk = remember(key) { Perms.hasUsageAccess(ctx) }
    val a11yOk = remember(key) { Perms.hasAccessibility(ctx) }
    val locOk = remember(key) { Perms.hasLocation(ctx) }
    val bgOk = remember(key) { Perms.hasBackgroundLocation(ctx) }
    val adminOk = remember(key) { Perms.isAdmin(ctx) }
    val deviceOwner = remember(key) { Perms.isDeviceOwner(ctx) }
    val batteryOk = remember(key) { Perms.ignoresBattery(ctx) }
    val coreOk = usageOk && a11yOk && locOk

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ShieldLogo(52.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Connected to $parentName", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Finish setup on this phone", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Prominent disclosure (required by Google Play before asking for these permissions).
        SectionCard {
            Text("What Family Shield shares", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "To keep you safe, this app collects which apps are installed, how long each app is used, " +
                        "this phone's location (also when the app is closed), and battery level. It shares this " +
                        "only with $parentName. It also uses Accessibility to see which app is open so it can apply " +
                        "the limits your parent set. It never reads your messages, photos, passwords or what you type. " +
                        "A notification always shows while Family Shield is on.",
                style = MaterialTheme.typography.bodyMedium
            )
            if (!accepted) {
                Spacer(Modifier.height(10.dp))
                Button(onClick = { accepted = true; prefs.disclosureAccepted = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("I understand, continue")
                }
            }
        }

        if (accepted) {
            if (Build.VERSION.SDK_INT >= 33) {
                SetupItem(Icons.Filled.Notifications, "Notifications", "Shows that protection is on", notifOk) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            SetupItem(Icons.Filled.QueryStats, "Usage access", "Measures screen time per app. Find Family Shield and turn it on.", usageOk) {
                openSettings(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS, withPackage = true)
            }
            SetupItem(
                Icons.Filled.Block, "App blocking",
                "Settings > Accessibility > Installed apps > Family Shield > turn on.", a11yOk
            ) { showA11yInfo = true }
            SetupItem(
                Icons.Filled.LocationOn, "Location",
                if (locOk && !bgOk) "Now choose \"Allow all the time\" so your parent sees where you are."
                else "Lets your parent see where you are and get home/school alerts.",
                locOk && bgOk
            ) {
                if (!locOk) locLauncher.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                ) else if (Build.VERSION.SDK_INT >= 29) bgLocLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
            SetupItem(
                Icons.Filled.AdminPanelSettings,
                "Uninstall protection",
                if (deviceOwner) "Android device-owner mode blocks removal; parent PIN can allow it."
                else "Device admin adds a confirmation step and alerts your parent if protection is turned off.",
                adminOk || deviceOwner
            ) {
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(ctx, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Your parent will be told if Family Shield is removed.")
                runCatching { adminLauncher.launch(i) }
            }
            SetupItem(Icons.Filled.BatteryChargingFull, "Keep running", "Battery > Unrestricted / Don't optimise for Family Shield", batteryOk || adminOk) {
                openSettings(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, withPackage = false)
            }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = onDone, enabled = coreOk,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text(if (coreOk) "Done" else "Turn on usage, blocking and location to continue") }
        }
    }

    if (showA11yInfo) {
        AlertDialog(
            onDismissRequest = { showA11yInfo = false },
            title = { Text("Turn on app blocking") },
            text = {
                Text(
                    "Family Shield uses Accessibility only to know which app is open, so it can pause apps your parent " +
                            "limited. It does not read the screen or anything you type.\n\n" +
                            "If the switch is greyed out (\"Restricted setting\"): open App info for Family Shield, " +
                            "tap the ⋮ menu at the top right and choose \"Allow restricted settings\", then try again."
                )
            },
            confirmButton = {
                Button(onClick = {
                    showA11yInfo = false
                    openSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS, withPackage = false)
                }) { Text("Open Accessibility") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showA11yInfo = false
                    openSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, withPackage = true)
                }) { Text("Open App info") }
            }
        )
    }
}

private fun openSettings(ctx: Context, action: String, withPackage: Boolean) {
    val pkgUri = Uri.parse("package:${ctx.packageName}")
    val tries = buildList {
        if (withPackage) add(Intent(action, pkgUri))
        add(Intent(action))
        add(Intent(Settings.ACTION_SETTINGS))
    }
    for (i in tries) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (_: Exception) {
        }
    }
}

@Composable
private fun SetupItem(icon: ImageVector, title: String, subtitle: String, done: Boolean, onClick: () -> Unit) {
    SectionCard(Modifier.clickable(enabled = !done, onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(42.dp)
                    .background(
                        (if (done) SafeGreen else MaterialTheme.colorScheme.primary).copy(alpha = 0.14f),
                        RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = if (done) SafeGreen else MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            if (done) Icon(Icons.Filled.CheckCircle, "Done", tint = SafeGreen)
            else FilledTonalButton(onClick = onClick) { Text("Allow") }
        }
    }
}

// ---------------- Home ----------------

@Composable
private fun ChildHome(parentName: String, uid: String, tick: Int, onOpenSetup: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rulesSnap by remember(uid) { Repo.rulesDoc(uid).asFlow() }.collectAsStateWithLifecycle(null)
    val rules = rulesSnap?.let { Rules.from(it) } ?: Rules()
    var usage by remember { mutableStateOf(UsageTracker.today(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            usage = UsageTracker.today(ctx, force = true)
            delay(30_000)
        }
    }
    val optionalMissing = remember(tick) { !Perms.isAdmin(ctx) || !Perms.hasBackgroundLocation(ctx) }
    var confirmSos by remember { mutableStateOf(false) }
    var pinPrompt by remember { mutableStateOf(false) }
    var uninstallPinPrompt by remember { mutableStateOf(false) }
    val requestSetup = { if (rules.pin.isBlank()) onOpenSetup() else pinPrompt = true }
    var sosState by remember { mutableStateOf(0) } // 0 idle, 1 sending, 2 sent
    val totalUsed = UsageTracker.totalMinutes(usage)
    val name = Prefs(ctx).childName

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ShieldLogo(52.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(if (name.isNotBlank()) "Hi, $name" else "Hi!", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text("Protected by $parentName", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (optionalMissing) {
            SectionCard(Modifier.clickable(onClick = requestSetup)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(10.dp))
                    Text("Finish setup: a few protections are still off. Tap here.", Modifier.weight(1f))
                }
            }
        }

        if (Perms.isDeviceOwner(ctx)) {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AdminPanelSettings, null, tint = SafeGreen)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Uninstall protection is enforced", fontWeight = FontWeight.Bold)
                        Text(
                            "Android blocks removal of Family Shield on this managed child phone.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { uninstallPinPrompt = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Parent: allow uninstall") }
            }
        }

        // Current mode
        val mode = when {
            rules.bedtimeOn && BlockPolicy.isBedtime(rules) -> "Bedtime"
            rules.studyOn -> "Study mode"
            else -> "Normal"
        }
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    when (mode) {
                        "Bedtime" -> Icons.Filled.Bedtime
                        "Study mode" -> Icons.Filled.MenuBook
                        else -> Icons.Filled.Shield
                    }, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when (mode) {
                            "Bedtime" -> "Bedtime until ${formatClock(rules.bedEnd)}"
                            "Study mode" -> "Study mode is on"
                            else -> "All good"
                        }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        when (mode) {
                            "Bedtime" -> "Apps are paused. Calls and SOS still work."
                            "Study mode" -> "Only study apps can open right now."
                            else -> if (rules.bedtimeOn) "Bedtime starts at ${formatClock(rules.bedStart)}" else "Use your phone wisely!"
                        },
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Screen time
        SectionCard {
            Text("Screen time today", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(formatMinutes(totalUsed), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            if (rules.totalLimit > 0) {
                val left = (rules.totalLimit - totalUsed).coerceAtLeast(0)
                Text(
                    if (left > 0) "${formatMinutes(left)} left of ${formatMinutes(rules.totalLimit)}" else "Today's time is over",
                    color = if (left > 0) MaterialTheme.colorScheme.onSurfaceVariant else SosRed
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (totalUsed.toFloat() / rules.totalLimit).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp)
                )
            }
            if (rules.limits.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Text("App limits", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(8.dp))
                val entries = rules.limits.entries.toList()
                UsageBars(entries.map { Essentials.appLabel(ctx, it.key) to (usage[it.key] ?: 0L) / 60_000 }) { i ->
                    entries[i].value
                }
            }
        }

        // SOS
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .size(150.dp)
                    .background(SosRed, CircleShape)
                    .clickable(enabled = sosState != 1) { confirmSos = true },
                contentAlignment = Alignment.Center
            ) {
                if (sosState == 1) CircularProgressIndicator(color = Color.White)
                else Text("SOS", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                when (sosState) {
                    2 -> "Sent! $parentName has been alerted with your location."
                    else -> "In danger? Tap SOS to alert $parentName with your location."
                },
                textAlign = TextAlign.Center,
                color = if (sosState == 2) SafeGreen else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Text(
            "Your parent helps keep this phone safe.",
            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth()
        )
    }

    if (confirmSos) {
        AlertDialog(
            onDismissRequest = { confirmSos = false },
            icon = { Icon(Icons.Filled.Sos, null, tint = SosRed) },
            title = { Text("Send SOS?") },
            text = { Text("$parentName will get an emergency alert with your location.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirmSos = false
                        sosState = 1
                        scope.launch {
                            runCatching { Sos.send(ctx) }
                            sosState = 2
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SosRed)
                ) { Text("Send SOS") }
            },
            dismissButton = { TextButton(onClick = { confirmSos = false }) { Text("Cancel") } }
        )
    }

    if (pinPrompt) {
        PinDialog(
            correctPin = rules.pin,
            onDismiss = { pinPrompt = false },
            onSuccess = { pinPrompt = false; onOpenSetup() }
        )
    }

    if (uninstallPinPrompt) {
        PinDialog(
            correctPin = rules.pin,
            onDismiss = { uninstallPinPrompt = false },
            onSuccess = {
                uninstallPinPrompt = false
                if (Perms.allowUninstallAfterParentPin(ctx)) {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${ctx.packageName}")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
        )
    }
}

/** Asks for the parent PIN before letting the child change protections. */
@Composable
private fun PinDialog(correctPin: String, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Lock, null) },
        title = { Text("Enter parent PIN") },
        text = {
            Column {
                Text(
                    "Changing protection settings needs the parent PIN.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = entry,
                    onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) { entry = it; error = false } },
                    label = { Text("4-digit PIN") },
                    singleLine = true,
                    isError = error,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (error) {
                    Spacer(Modifier.height(6.dp))
                    Text("Wrong PIN", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (entry == correctPin && correctPin.isNotBlank()) onSuccess() else error = true }) {
                Text("Unlock")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
