package com.rajeev.familyshield.child

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.rajeev.familyshield.data.AlertType
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Repo
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

object Sos {
    /** Sends an SOS with the best location we can get within ~10 seconds. */
    @SuppressLint("MissingPermission")
    suspend fun send(ctx: Context) {
        val prefs = Prefs(ctx)
        val who = prefs.childName.ifBlank { "Your child" }
        var lat: Double? = null
        var lng: Double? = null
        if (Perms.hasLocation(ctx)) {
            val client = LocationServices.getFusedLocationProviderClient(ctx)
            val loc = withTimeoutOrNull(10_000) {
                try {
                    client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                } catch (e: Exception) {
                    null
                }
            } ?: try {
                client.lastLocation.await()
            } catch (e: Exception) {
                null
            }
            if (loc != null) {
                lat = loc.latitude
                lng = loc.longitude
                Repo.updateChildStatus(
                    mapOf("lat" to lat, "lng" to lng, "locTime" to System.currentTimeMillis())
                )
            }
        }
        Repo.sendAlert(
            prefs, AlertType.SOS, "SOS from $who",
            if (lat != null) "$who needs help. Tap to see where they are." else "$who needs help. Location is not available.",
            lat, lng
        )
    }
}
