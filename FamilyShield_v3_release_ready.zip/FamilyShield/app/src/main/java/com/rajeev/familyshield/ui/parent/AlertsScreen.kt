package com.rajeev.familyshield.ui.parent

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.firebase.firestore.Query
import com.rajeev.familyshield.data.AlertItem
import com.rajeev.familyshield.data.AlertType
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.asFlow
import com.rajeev.familyshield.data.formatAgo
import com.rajeev.familyshield.ui.theme.KidOrange
import com.rajeev.familyshield.ui.theme.SafeGreen
import com.rajeev.familyshield.ui.theme.ShieldBlue
import com.rajeev.familyshield.ui.theme.SosRed
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertsScreen(onBack: () -> Unit) {
    val uid = Repo.me?.uid ?: return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snap by remember(uid) {
        Repo.alertsCol(uid).orderBy("time", Query.Direction.DESCENDING).limit(150).asFlow()
    }.collectAsStateWithLifecycle(null)
    val alerts = snap?.documents?.map { AlertItem.from(it) } ?: emptyList()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Alerts", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    TextButton(onClick = { scope.launch { runCatching { Repo.markAllRead(uid) } } }) {
                        Text("Mark all read")
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        if (snap != null && alerts.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.NotificationsNone, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text("No alerts yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(alerts, key = { it.id }) { a ->
                val (icon, color) = styleFor(a.type)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (!a.read) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else Color.Transparent)
                        .clickable {
                            if (!a.read) Repo.markAlertRead(uid, a.id)
                            if (a.lat != null && a.lng != null) {
                                runCatching {
                                    ctx.startActivity(
                                        Intent(
                                            Intent.ACTION_VIEW,
                                            Uri.parse("geo:${a.lat},${a.lng}?q=${a.lat},${a.lng}(${Uri.encode(a.childName)})")
                                        )
                                    )
                                }
                            }
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        Modifier.size(42.dp).background(color.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = color) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.title, fontWeight = if (a.read) FontWeight.Normal else FontWeight.Bold,
                            color = if (a.type == AlertType.SOS) SosRed else MaterialTheme.colorScheme.onSurface)
                        Text(a.message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(2.dp))
                        Row {
                            Text(formatAgo(a.time), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (a.lat != null) {
                                Text("  •  Tap to see on map", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun styleFor(type: String): Pair<androidx.compose.ui.graphics.vector.ImageVector, Color> = when (type) {
    AlertType.SOS -> Icons.Filled.Sos to SosRed
    AlertType.NEW_APP -> Icons.Filled.GetApp to ShieldBlue
    AlertType.ARRIVED -> Icons.Filled.Place to SafeGreen
    AlertType.LEFT -> Icons.Filled.WrongLocation to KidOrange
    AlertType.PROTECTION_OFF -> Icons.Filled.GppBad to SosRed
    AlertType.LIMIT -> Icons.Filled.HourglassBottom to KidOrange
    AlertType.TAMPER -> Icons.Filled.GppBad to SosRed
    else -> Icons.Filled.Notifications to ShieldBlue
}
