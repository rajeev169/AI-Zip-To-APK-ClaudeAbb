package com.rajeev.familyshield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.rajeev.familyshield.child.MonitorService
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Role
import com.rajeev.familyshield.parent.ParentAlertService

/** Restarts protection (child) or alert listening (parent) after the phone restarts or the app updates. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = Prefs(context)
        when {
            prefs.role == Role.CHILD && prefs.linked -> MonitorService.start(context)
            prefs.role == Role.PARENT -> ParentAlertService.start(context)
        }
    }
}
