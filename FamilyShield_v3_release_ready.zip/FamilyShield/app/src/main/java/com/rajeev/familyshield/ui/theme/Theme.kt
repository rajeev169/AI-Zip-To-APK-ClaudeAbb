package com.rajeev.familyshield.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ShieldBlue = Color(0xFF1E6FD9)
val ShieldBlueDark = Color(0xFF0B4FA8)
val KidOrange = Color(0xFFF5A524)
val SafeGreen = Color(0xFF12A37A)
val SosRed = Color(0xFFE5383B)

private val Light = lightColorScheme(
    primary = ShieldBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE8FB),
    onPrimaryContainer = ShieldBlueDark,
    secondary = KidOrange,
    onSecondary = Color(0xFF3A2500),
    secondaryContainer = Color(0xFFFFEBC7),
    onSecondaryContainer = Color(0xFF5A3A00),
    tertiary = SafeGreen,
    background = Color(0xFFF6F8FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFEEF2F8),
    error = SosRed,
)

private val Dark = darkColorScheme(
    primary = Color(0xFF8DB8F5),
    onPrimary = Color(0xFF002F67),
    primaryContainer = Color(0xFF0B4FA8),
    onPrimaryContainer = Color(0xFFDCE8FB),
    secondary = KidOrange,
    onSecondary = Color(0xFF3A2500),
    secondaryContainer = Color(0xFF5A3A00),
    onSecondaryContainer = Color(0xFFFFEBC7),
    tertiary = Color(0xFF5FD3AE),
    error = Color(0xFFFF8A80),
)

@Composable
fun FamilyShieldTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
