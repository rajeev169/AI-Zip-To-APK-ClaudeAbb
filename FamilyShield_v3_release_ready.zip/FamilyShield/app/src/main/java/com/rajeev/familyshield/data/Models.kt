package com.rajeev.familyshield.data

import com.google.firebase.firestore.DocumentSnapshot
import org.json.JSONArray
import org.json.JSONObject

object Role {
    const val PARENT = "parent"
    const val CHILD = "child"
}

data class ChildInfo(
    val uid: String,
    val name: String,
    val email: String,
    val parentUid: String,
    val parentName: String,
    val device: String,
    val lastSeen: Long,
    val battery: Int,
    val charging: Boolean,
    val lat: Double?,
    val lng: Double?,
    val locTime: Long,
    val todayDate: String,
    val todayTotalMin: Long,
    val currentPlace: String,
    val protection: Map<String, Boolean>,
) {
    val hasLocation get() = lat != null && lng != null
    val missingProtection: List<String>
        get() = PROTECTION_LABELS.filter { protection[it.key] == false }.map { it.value }

    companion object {
        val PROTECTION_LABELS = linkedMapOf(
            "usage" to "Usage access",
            "accessibility" to "App blocking (Accessibility)",
            "location" to "Location",
            "admin" to "Uninstall protection",
        )

        fun from(d: DocumentSnapshot): ChildInfo? {
            if (!d.exists()) return null
            @Suppress("UNCHECKED_CAST")
            val prot = (d.get("protection") as? Map<String, Any?>)
                ?.mapValues { it.value == true } ?: emptyMap()
            return ChildInfo(
                uid = d.id,
                name = d.getString("name") ?: "Child",
                email = d.getString("email") ?: "",
                parentUid = d.getString("parentUid") ?: "",
                parentName = d.getString("parentName") ?: "Parent",
                device = d.getString("device") ?: "",
                lastSeen = d.getLong("lastSeen") ?: 0L,
                battery = (d.getLong("battery") ?: -1L).toInt(),
                charging = d.getBoolean("charging") ?: false,
                lat = d.getDouble("lat"),
                lng = d.getDouble("lng"),
                locTime = d.getLong("locTime") ?: 0L,
                todayDate = d.getString("todayDate") ?: "",
                todayTotalMin = d.getLong("todayTotalMin") ?: 0L,
                currentPlace = d.getString("currentPlace") ?: "",
                protection = prot,
            )
        }
    }
}

data class Invite(
    val email: String,
    val parentUid: String,
    val parentName: String,
    val childName: String,
    val status: String,
) {
    companion object {
        fun from(d: DocumentSnapshot): Invite? {
            if (!d.exists()) return null
            return Invite(
                email = d.id,
                parentUid = d.getString("parentUid") ?: return null,
                parentName = d.getString("parentName") ?: "Parent",
                childName = d.getString("childName") ?: "",
                status = d.getString("status") ?: "pending",
            )
        }
    }
}

data class Place(val name: String, val lat: Double, val lng: Double, val radius: Int) {
    fun toMap() = mapOf("name" to name, "lat" to lat, "lng" to lng, "radius" to radius)
}

data class Rules(
    val blocked: Set<String> = emptySet(),
    val limits: Map<String, Long> = emptyMap(),   // package -> minutes per day
    val totalLimit: Long = 0L,                    // minutes per day, 0 = no limit
    val bedtimeOn: Boolean = false,
    val bedStart: Int = 21 * 60,                  // minutes after midnight
    val bedEnd: Int = 7 * 60,
    val studyOn: Boolean = false,
    val studyAllowed: Set<String> = emptySet(),
    val places: List<Place> = emptyList(),
    val pin: String = "",
    val cmdId: String = "",
    val cmdType: String = "",
    val approveNew: Boolean = false,              // new installs stay locked until the parent approves
    val approved: Set<String> = emptySet(),       // packages the parent has approved
    val lockSettings: Boolean = true,             // sensitive Settings pages need the parent PIN
    val lockAllSettings: Boolean = false,         // every Settings page needs the parent PIN
    val lockOnProtectionOff: Boolean = true,      // full-screen lock while a protection is off
) {
    fun toJson(): String = JSONObject().apply {
        put("blocked", JSONArray(blocked.toList()))
        put("limits", JSONObject(limits as Map<*, *>))
        put("totalLimit", totalLimit)
        put("bedtimeOn", bedtimeOn)
        put("bedStart", bedStart)
        put("bedEnd", bedEnd)
        put("studyOn", studyOn)
        put("studyAllowed", JSONArray(studyAllowed.toList()))
        put("places", JSONArray().apply {
            places.forEach {
                put(JSONObject().put("name", it.name).put("lat", it.lat).put("lng", it.lng).put("radius", it.radius))
            }
        })
        put("pin", pin)
        put("cmdId", cmdId)
        put("cmdType", cmdType)
        put("approveNew", approveNew)
        put("approved", JSONArray(approved.toList()))
        put("lockSettings", lockSettings)
        put("lockAllSettings", lockAllSettings)
        put("lockOnProtectionOff", lockOnProtectionOff)
    }.toString()

    companion object {
        fun from(d: DocumentSnapshot?): Rules {
            if (d == null || !d.exists()) return Rules()
            @Suppress("UNCHECKED_CAST")
            val limits = (d.get("limits") as? Map<String, Any?>)
                ?.mapNotNull { (k, v) -> (v as? Number)?.let { k to it.toLong() } }?.toMap() ?: emptyMap()
            @Suppress("UNCHECKED_CAST")
            val places = (d.get("places") as? List<Map<String, Any?>>)?.mapNotNull { m ->
                val lat = (m["lat"] as? Number)?.toDouble() ?: return@mapNotNull null
                val lng = (m["lng"] as? Number)?.toDouble() ?: return@mapNotNull null
                Place(m["name"] as? String ?: "Place", lat, lng, (m["radius"] as? Number)?.toInt() ?: 200)
            } ?: emptyList()
            return Rules(
                blocked = stringList(d.get("blocked")).toSet(),
                limits = limits,
                totalLimit = d.getLong("totalLimit") ?: 0L,
                bedtimeOn = d.getBoolean("bedtimeOn") ?: false,
                bedStart = (d.getLong("bedStart") ?: (21 * 60L)).toInt(),
                bedEnd = (d.getLong("bedEnd") ?: (7 * 60L)).toInt(),
                studyOn = d.getBoolean("studyOn") ?: false,
                studyAllowed = stringList(d.get("studyAllowed")).toSet(),
                places = places,
                pin = d.getString("pin") ?: "",
                cmdId = d.getString("cmdId") ?: "",
                cmdType = d.getString("cmdType") ?: "",
                approveNew = d.getBoolean("approveNew") ?: false,
                approved = stringList(d.get("approved")).toSet(),
                lockSettings = d.getBoolean("lockSettings") ?: true,
                lockAllSettings = d.getBoolean("lockAllSettings") ?: false,
                lockOnProtectionOff = d.getBoolean("lockOnProtectionOff") ?: true,
            )
        }

        fun fromJson(s: String?): Rules {
            if (s.isNullOrBlank()) return Rules()
            return try {
                val o = JSONObject(s)
                val lim = o.optJSONObject("limits")
                val limits = mutableMapOf<String, Long>()
                lim?.keys()?.forEach { k -> limits[k] = lim.optLong(k) }
                val pl = o.optJSONArray("places") ?: JSONArray()
                val places = (0 until pl.length()).map { i ->
                    val p = pl.getJSONObject(i)
                    Place(p.optString("name"), p.optDouble("lat"), p.optDouble("lng"), p.optInt("radius", 200))
                }
                Rules(
                    blocked = jsonStrings(o.optJSONArray("blocked")).toSet(),
                    limits = limits,
                    totalLimit = o.optLong("totalLimit"),
                    bedtimeOn = o.optBoolean("bedtimeOn"),
                    bedStart = o.optInt("bedStart", 21 * 60),
                    bedEnd = o.optInt("bedEnd", 7 * 60),
                    studyOn = o.optBoolean("studyOn"),
                    studyAllowed = jsonStrings(o.optJSONArray("studyAllowed")).toSet(),
                    places = places,
                    pin = o.optString("pin"),
                    cmdId = o.optString("cmdId"),
                    cmdType = o.optString("cmdType"),
                    approveNew = o.optBoolean("approveNew"),
                    approved = jsonStrings(o.optJSONArray("approved")).toSet(),
                    lockSettings = o.optBoolean("lockSettings", true),
                    lockAllSettings = o.optBoolean("lockAllSettings", false),
                    lockOnProtectionOff = o.optBoolean("lockOnProtectionOff", true),
                )
            } catch (e: Exception) {
                Rules()
            }
        }

        private fun stringList(v: Any?): List<String> =
            (v as? List<*>)?.mapNotNull { it as? String } ?: emptyList()

        private fun jsonStrings(a: JSONArray?): List<String> =
            if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }
    }
}

data class AppEntry(val pkg: String, val name: String, val firstSeen: Long, val pending: Boolean = false)

data class AlertItem(
    val id: String,
    val type: String,
    val childUid: String,
    val childName: String,
    val title: String,
    val message: String,
    val time: Long,
    val lat: Double?,
    val lng: Double?,
    val read: Boolean,
) {
    companion object {
        fun from(d: DocumentSnapshot): AlertItem = AlertItem(
            id = d.id,
            type = d.getString("type") ?: "info",
            childUid = d.getString("childUid") ?: "",
            childName = d.getString("childName") ?: "",
            title = d.getString("title") ?: "",
            message = d.getString("message") ?: "",
            time = d.getLong("time") ?: 0L,
            lat = d.getDouble("lat"),
            lng = d.getDouble("lng"),
            read = d.getBoolean("read") ?: false,
        )
    }
}

object AlertType {
    const val SOS = "sos"
    const val NEW_APP = "new_app"
    const val ARRIVED = "arrived"
    const val LEFT = "left"
    const val PROTECTION_OFF = "protection_off"
    const val LIMIT = "limit"
    const val TAMPER = "tamper"
}
