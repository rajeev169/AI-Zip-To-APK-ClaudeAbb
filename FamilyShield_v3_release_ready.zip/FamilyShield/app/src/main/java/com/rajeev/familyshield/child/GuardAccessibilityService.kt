package com.rajeev.familyshield.child

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.rajeev.familyshield.data.Prefs

/**
 * Watches which app comes to the front and the visible system uninstall flow,
 * showing a block screen or parent-PIN gate when the parent's rules require it.
 */
class GuardAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GuardAccessibilityService? = null
            private set

        /** Package of the app currently in front, as seen by this service. */
        @Volatile
        var currentPackage: String? = null
            private set

        /** Settings apps on common phones. Their pages can be locked behind the parent PIN. */
        val SETTINGS_PACKAGES = setOf("com.android.settings", "com.vivo.settings", "com.coloros.settings")

        /** Text that only appears on pages that can switch Family Shield protection off. */
        private val SENSITIVE_ALWAYS = listOf(
            "apps with usage access",
            "permit usage access",
            "usage data access",
            "device admin apps",
            "device administrator",
            "usb debugging",
            "use family shield",
            "family shield shortcut",
        )

        /** Pages that mention Family Shield together with one of these are sensitive too. */
        private val SENSITIVE_WITH_APP = listOf(
            "accessibility",
            "usage access",
            "device admin",
            "force stop",
            "clear data",
            "clear storage",
            "app info",
        )

        private val SETUP_MARKERS = listOf(
            "full control of your device",
            "view and control screen",
            "view and perform actions",
            "use family shield",
            "family shield shortcut",
            "permit usage access",
            "usage access allows",
            "display over other apps",
            "allow display over",
            "device admin",
            "device administrator",
            "activate this device",
            "accessibility"
        )
    }

    private var lastBlockedPkg: String? = null
    private var lastBlockTime = 0L
    private var lastUninstallPrompt = 0L
    private var lastSettingsPrompt = 0L
    private var lastSettingsScan = 0L
    private var lastLockPkg: String? = null
    private var lastLockTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        if (Prefs(this).linked) MonitorService.start(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (isUninstallAttempt(pkg)) {
            promptForUninstallPin()
            return
        }
        if (isSettingsGateNeeded(pkg)) {
            promptForSettingsPin()
            return
        }
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        // Keyboard and system overlays should not change the "current app".
        if (pkg == "com.android.systemui" || isKeyboard(pkg)) return
        currentPackage = pkg
        check(pkg)
    }

    /** Detects only the system uninstall flow for Family Shield, not general Settings usage. */
    private fun isUninstallAttempt(pkg: String): Boolean {
        val prefs = Prefs(this)
        if (!prefs.linked || pkg == packageName || prefs.uninstallUnlockUntil > System.currentTimeMillis()) return false
        val systemPackage = pkg == "com.android.settings" ||
            pkg == "com.android.packageinstaller" ||
            pkg == "com.google.android.packageinstaller" ||
            pkg == "com.android.permissioncontroller"
        if (!systemPackage) return false
        val root = rootInActiveWindow ?: return false
        val text = StringBuilder()
        collectText(root, text)
        val screen = text.toString().lowercase()
        // Permission / accessibility / setup screens for Family Shield also mention "uninstall"
        // (the permission dialog even has an Uninstall button), so never treat them as an uninstall attempt.
        val setupScreen = SETUP_MARKERS.any { screen.contains(it) }
        if (setupScreen) return false
        val uninstall = screen.contains("uninstall") || screen.contains("remove app") || screen.contains("delete app")
        val target = screen.contains("family shield") || screen.contains(packageName.lowercase())
        return uninstall && target
    }

    /** True when a Settings page that could weaken protection is on screen and the PIN was not entered. */
    private fun isSettingsGateNeeded(pkg: String): Boolean {
        if (pkg !in SETTINGS_PACKAGES) return false
        val prefs = Prefs(this)
        val now = System.currentTimeMillis()
        if (!prefs.linked || prefs.settingsUnlockUntil > now) return false
        val rules = RulesStore.get(this)
        if (rules.pin.isBlank()) return false // no PIN yet, so nothing could be unlocked
        if (rules.lockAllSettings) return true
        if (!rules.lockSettings) return false
        if (now - lastSettingsScan < 400L) return false
        lastSettingsScan = now
        val root = rootInActiveWindow ?: return false
        val text = StringBuilder()
        collectText(root, text)
        val screen = text.toString().lowercase()
        if (SENSITIVE_ALWAYS.any { screen.contains(it) }) return true
        return screen.contains("family shield") && SENSITIVE_WITH_APP.any { screen.contains(it) }
    }

    private fun promptForSettingsPin() {
        val now = System.currentTimeMillis()
        if (now - lastSettingsPrompt < 1200L) return
        lastSettingsPrompt = now
        val intent = android.content.Intent(this, UninstallGuardActivity::class.java)
            .putExtra(UninstallGuardActivity.EXTRA_MODE, UninstallGuardActivity.MODE_SETTINGS)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder) {
        if (node == null) return
        node.text?.let { out.append(' ').append(it) }
        node.contentDescription?.let { out.append(' ').append(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out)
    }

    private fun promptForUninstallPin() {
        val now = System.currentTimeMillis()
        if (now - lastUninstallPrompt < 1200L) return
        lastUninstallPrompt = now
        val intent = android.content.Intent(this, UninstallGuardActivity::class.java)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun isKeyboard(pkg: String): Boolean {
        val ime = android.provider.Settings.Secure.getString(
            contentResolver, android.provider.Settings.Secure.DEFAULT_INPUT_METHOD
        ) ?: return false
        return ime.startsWith("$pkg/")
    }

    /** Called on every app switch and every 30 seconds by MonitorService. */
    fun check(pkg: String? = currentPackage) {
        if (pkg == null || pkg == packageName) return
        if (ProtectionLock.needsLock(this) && !ProtectionLock.isExempt(this, pkg)) {
            val t = System.currentTimeMillis()
            if (pkg == lastLockPkg && t - lastLockTime < 1500L) return
            lastLockPkg = pkg
            lastLockTime = t
            ProtectionLock.show(this)
            return
        }
        val reason = BlockPolicy.reason(this, pkg) ?: return
        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1500) return
        lastBlockedPkg = pkg
        lastBlockTime = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        BlockActivity.show(this, pkg, reason)
        MonitorService.onAppBlocked(this, pkg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
