package com.rajeev.familyshield.data

import android.app.Activity
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.rajeev.familyshield.R
import kotlinx.coroutines.tasks.await

object GoogleAuth {
    /** Returns null on success, or a message to show. */
    suspend fun signIn(activity: Activity): String? {
        return try {
            val option = GetSignInWithGoogleOption.Builder(activity.getString(R.string.default_web_client_id)).build()
            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val result = CredentialManager.create(activity).getCredential(activity, request)
            val cred = result.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val google = GoogleIdTokenCredential.createFrom(cred.data)
                val firebaseCred = GoogleAuthProvider.getCredential(google.idToken, null)
                FirebaseAuth.getInstance().signInWithCredential(firebaseCred).await()
                null
            } else {
                "Unexpected sign-in type"
            }
        } catch (e: GetCredentialCancellationException) {
            null
        } catch (e: Exception) {
            e.message ?: "Sign-in failed"
        }
    }

    suspend fun signOut(activity: Activity) {
        FirebaseAuth.getInstance().signOut()
        try {
            CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest())
        } catch (_: Exception) {
        }
    }
}
